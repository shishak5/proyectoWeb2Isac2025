// Arreglo global para almacenar los usuarios
let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

// Función que se ejecuta cuando el documento se carga completamente
document.addEventListener('DOMContentLoaded', function () {

    // Comprobar si estamos en la página de registro o inicio de sesión
    if (document.getElementById('registerForm')) {
        // Página de registro
        const form = document.getElementById('registerForm');
        const nameField = document.getElementById('name');
        const addressField = document.getElementById('address');
        const phoneField = document.getElementById('phone');
        const emailField = document.getElementById('email');
        const passwordField = document.getElementById('password');

        // Función de validación para los datos de registro
        form.addEventListener('submit', function (event) {
            event.preventDefault(); // Prevenir que el formulario se envíe automáticamente

            let valid = true;

            // Validar campos
            if (!nameField.value.trim() || !addressField.value.trim() || !phoneField.value.trim() || !emailField.value.trim() || !passwordField.value.trim()) {
                alert('Por favor, llena todos los campos.');
                valid = false;
            }

            if (valid) {
                // Crear un nuevo objeto usuario
                const nuevoUsuario = {
                    name: nameField.value,
                    address: addressField.value,
                    phone: phoneField.value,
                    email: emailField.value,
                    password: passwordField.value
                };

                // Guardar el usuario en el arreglo
                usuarios.push(nuevoUsuario);

                // Guardar el arreglo actualizado en localStorage
                localStorage.setItem('usuarios', JSON.stringify(usuarios));

                alert('¡Registro exitoso!');
                window.location.href = "inicio.html"; // Redirigir a inicio de sesión
            }
        });

    } else if (document.getElementById('loginForm')) {
        // Página de inicio de sesión
        const form = document.getElementById('loginForm');
        const emailField = document.getElementById('email');
        const passwordField = document.getElementById('password');
        const error = document.getElementById('error');

        // Función de validación para el inicio de sesión
        form.addEventListener('submit', function (event) {
            event.preventDefault(); // Prevenir que el formulario se envíe automáticamente

            let valid = true;
            
            error.textContent = '';

            // Verificar si los campos están vacíos
            if (!emailField.value.trim() || !passwordField.value.trim() ) {
                valid = false;
            }


            if (valid) {
                // Verificar si las credenciales son correctas
                const usuarioEncontrado = usuarios.find(usuario => usuario.email === emailField.value && usuario.password === passwordField.value);

                if (usuarioEncontrado) {
                    
                    window.location.href = "carniceria.html"; // Redirigir a la página principal
                } else {
                    error.textContent = 'Correo o contraseña incorrectos';
                
                }
            }
        });
    }
});

