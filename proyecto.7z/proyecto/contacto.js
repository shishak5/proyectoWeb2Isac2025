// scripts.js
document.querySelector('.contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevenir el envío del formulario

    // Obtener los valores del formulario
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Verificar si los campos están vacíos
    if (name === '' || email === '' || message === '') {
        
    } else {
        alert('¡Mensaje enviado exitosamente!');
        
    }
});
